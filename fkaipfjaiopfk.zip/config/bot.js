require('dotenv').config();

module.exports = {
    token: process.env.token,
    prefix: process.env.prefix
}